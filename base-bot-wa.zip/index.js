const nodejs = require("wmbotme");
const fs = require('fs');
const os = require('os');
const pino = require('pino');
const path = require('path');
const axios = require('axios');
const chalk = require('chalk');
const readline = require('readline');
const { Boom } = require('@hapi/boom');
const qrcode = require('qrcode-terminal');
const NodeCache = require('node-cache');
const { toBuffer, toDataURL } = require('qrcode');
const { exec, spawn, execSync } = require('child_process');
const { parsePhoneNumber } = require('awesome-phonenumber');
const { default: WAConnection, useMultiFileAuthState, Browsers, DisconnectReason, makeInMemoryStore, makeCacheableSignalKeyStore, fetchLatestBaileysVersion, proto, jidNormalizedUser, getAggregateVotesInPollMessage, makeWASocket, downloadMediaMessage } = require('@whiskeysockets/baileys');
const { app, server, PORT } = require('./lib/server');
const { dataBase } = require('./lib/database');
const pair = true;
const pairingCode = process.argv.includes('--qr') ? false : process.argv.includes('--pairing-code') || pair;
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))
let pairingStarted = false;
const storeDB = dataBase("baileys_store.json");
const database = dataBase("database1.json");
const db = require('./lib/db')
const handleMessage = require('./lib/handler')
const groupParticipantsUpdate = require('./lib/group-participants')
const antiCallHandler = require('./lib/anticall')

global.plugins = []

function loadCommands(dir = path.join(__dirname, './commands')) {
  global.plugins = []

  const walk = (folder) => {
    fs.readdirSync(folder).forEach(file => {
      let filepath = path.join(folder, file)
      if (fs.lstatSync(filepath).isDirectory()) {
        walk(filepath)
      } else if (file.endsWith('.js')) {
        try {
          delete require.cache[require.resolve(filepath)]
          let cmd = require(filepath)
          global.plugins.push(cmd)
          console.log(`✅ Loaded: ${path.relative(dir, filepath)}`)
        } catch (e) {
          console.error(`❌ Error load plugin ${filepath}:`, e)
        }
      }
    })
  }

  walk(dir)
}

function watchCommands(dir = path.join(__dirname, './commands')) {
  fs.watch(dir, { recursive: true }, (event, filename) => {
    if (!filename.endsWith('.js')) return
    console.log(`♻️ Plugin ${filename} changed, reloading...`)
    loadCommands(dir)
  })
}

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState('auth');
	const { version, isLatest } = await fetchLatestBaileysVersion();
	const level = pino({ level: 'silent' });
  const usePairingCode = true;
	
	const conn = makeWASocket({
		printQRInTerminal: !usePairingCode,
		syncFullHistory: true,
		markOnlineOnConnect: true,
		connectTimeoutMs: 60000, 
		defaultQueryTimeoutMs: 0,
		keepAliveIntervalMs: 10000,
		generateHighQualityLinkPreview: true, 
		patchMessageBeforeSending: (message) => {
			const requiresPatch = !!(
				message.buttonsMessage 
				|| message.templateMessage
				|| message.listMessage
			);
			if (requiresPatch) {
				message = {
					viewOnceMessage: {
						message: {
							messageContextInfo: {
								deviceListMetadataVersion: 2,
								deviceListMetadata: {},
							},
							...message,
						},
					},
				};
			}

			return message;
		},
		version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
		browser: ["Windows", "Chrome", "20.0.04"],
		logger: pino({ level: 'fatal' }),
		auth: { 
			creds: state.creds, 
			keys: makeCacheableSignalKeyStore(state.keys, pino().child({ 
				level: 'silent', 
				stream: 'store' 
			})), 
		}
	});
	
	if (pairingCode && !conn.authState.creds.registered) {
		(async () => {
			await exec('rm -rf ./auth/*');
		})()
	}
	conn.decodeJid = (jid) => {
		if (!jid) return jid
		if (/:\d+@/gi.test(jid)) {
			let decode = jidDecode(jid) || {}
			return decode.user && decode.server && decode.user + '@' + decode.server || jid
		} else return jid
	}
  loadCommands()
watchCommands()

  conn.ev.on('messages.upsert', async ({ messages }) => {
  let raw = messages[0]
  if (!raw.message) return

  raw.chat = raw.key.remoteJid
  raw.sender = raw.key.fromMe ? conn.user.id : (raw.key.participant || raw.key.remoteJid)
  raw.isGroup = raw.chat.endsWith('@g.us')
  raw.pushName = raw.pushName || 'User'
  raw.text =
    raw.message.conversation ||
    raw.message.extendedTextMessage?.text ||
    raw.message.imageMessage?.caption ||
    raw.message.videoMessage?.caption ||
    ''

  // 🔽 handle quoted
  if (raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
    const ctx = raw.message.extendedTextMessage.contextInfo
    const quoted = ctx.quotedMessage
    const type = Object.keys(quoted)[0]
    const msg = quoted[type]

    raw.quoted = {
      key: {
        remoteJid: ctx.remoteJid || raw.chat,
        fromMe: ctx.participant
          ? jidNormalizedUser(ctx.participant) === jidNormalizedUser(conn.user.id)
          : false,
        id: ctx.stanzaId,
        participant: ctx.participant,
      },
      message: quoted,
      type,
      msg,
      text:
        msg?.text ||
        msg?.conversation ||
        msg?.caption ||
        msg?.contentText ||
        msg?.selectedDisplayText ||
        msg?.title ||
        (typeof msg === 'string' ? msg : '') ||
        '',
      isMedia: !!(msg?.mimetype || msg?.thumbnailDirectPath),
      download: () =>
        downloadMediaMessage(
          { message: quoted },
          'buffer',
          {},
          { logger: console, reuploadRequest: conn.updateMediaMessage }
        ),
    }
  }

  // helper reply
  raw.reply = (txt) => conn.sendMessage(raw.chat, { text: txt }, { quoted: raw })

  // cek admin kalau group
  if (raw.isGroup) {
    let metadata = await conn.groupMetadata(raw.chat)
    raw.isAdmin = metadata.participants.find(p => p.id === raw.sender)?.admin != null
    raw.isBotAdmin = metadata.participants.find(p => p.id === conn.user.id)?.admin != null
  }

  // teruskan ke handler
  await handleMessage(raw, { conn, usedPrefixList: ['.', '!', '/'] })
})
  conn.ev.on('group-participants.update', async (update) => {
  try {
    await groupParticipantsUpdate(conn, update)
  } catch (e) {
    console.error('Error group-participants.update:', e)
  }
})
conn.ev.on('call', async (call) => {
  try {
    await antiCallHandler(conn, call)
  } catch (e) {
    console.error('Error antiCall:', e)
  }
})

  conn.ev.on('creds.update', saveCreds)
	
	conn.ev.on('connection.update', async (update) => {
		const { qr, connection, lastDisconnect, isNewLogin, receivedPendingNotifications } = update
		try {
		const loadData = await database.read()
		const storeLoadData = await storeDB.read()
		if (!loadData || Object.keys(loadData).length === 0) {
			global.db = {
				hit: {},
				set: {},
				cmd: {},
				store: {},
				users: {},
				game: {},
				groups: {},
				database: {},
				premium: [],
				sewa: [],
				...(loadData || {}),
			}
			await database.write(global.db)
		} else {
			global.db = loadData
		}
		if (!storeLoadData || Object.keys(storeLoadData).length === 0) {
			global.store = {
				contacts: {},
				presences: {},
				messages: {},
				groupMetadata: {},
				...(storeLoadData || {}),
			}
			await storeDB.write(global.store)
		} else {
			global.store = storeLoadData
		}
		
		setInterval(async () => {
			if (global.db) await database.write(global.db)
			if (global.store) await storeDB.write(global.store)
		}, 30 * 1000)
	} catch (e) {
		console.log(e)
		process.exit(1)
	}
		if (!conn.authState.creds.registered) console.log('Connection: ', connection || false);
		if ((connection === 'connecting' || !!qr) && pairingCode && !conn.authState.creds.registered && !pairingStarted) {
			setTimeout(async () => {
				pairingStarted = true;
				const phone_number = await question(chalk.green(">Masukan Nomer Yang Aktif Awali Dengan 62 Recode :\n"));
    try {
        const code = await conn.requestPairingCode(phone_number, "NDIKZONE");
        console.log(chalk.green(`\n[✓] Kode Pairing Anda: ${chalk.bold.white(code?.match(/.{1,4}/g)?.join('-') || code)}`));
    } catch (error) {
        console.log(chalk.red(`\n[✗] Gagal meminta kode pairing: ${error.message}`));
        process.exit(1);
    }
			}, 3000)
		}
		if (connection === 'close') {
			const reason = new Boom(lastDisconnect?.error)?.output.statusCode
			if (reason === DisconnectReason.connectionLost) {
				console.log('Connection to Server Lost, Attempting to Reconnect...');
				start()
			} else if (reason === DisconnectReason.connectionClosed) {
				console.log('Connection closed, Attempting to Reconnect...');
				start()
			} else if (reason === DisconnectReason.restartRequired) {
				console.log('Restart Required...');
				start()
			} else if (reason === DisconnectReason.timedOut) {
				console.log('Connection Timed Out, Attempting to Reconnect...');
				start()
			} else if (reason === DisconnectReason.badSession) {
				console.log('Delete Session and Scan again...');
				start()
			} else if (reason === DisconnectReason.connectionReplaced) {
				console.log('Close current Session first...');
			} else if (reason === DisconnectReason.loggedOut) {
				console.log('Scan again and Run...');
				exec('rm -rf ./auth/*')
				process.exit(1)
			} else if (reason === DisconnectReason.forbidden) {
				console.log('Connection Failure, Scan again and Run...');
				exec('rm -rf ./auth/*')
				process.exit(1)
			} else if (reason === DisconnectReason.multideviceMismatch) {
				console.log('Scan again...');
				exec('rm -rf ./auth/*')
				process.exit(0)
			} else {
				conn.end(`Unknown DisconnectReason : ${reason}|${connection}`)
			}
		}
		if (connection == 'open') {
			console.log('Connected to : ' + JSON.stringify(conn.user, null, 2));
		}
		if (qr) {
			if (!pairingCode) qrcode.generate(qr, { small: true })
			app.use('/qr', async (req, res) => {
				res.setHeader('content-type', 'image/png')
				res.end(await toBuffer(qr))
			});
		}
		if (isNewLogin) console.log(chalk.green('New device login detected...'))
		if (receivedPendingNotifications == 'true') {
			console.log('Please wait About 1 Minute...')
			conn.ev.flush()
		}
	});
	conn.ev.on('contacts.update', update => {
		for (let contact of update) {
			let id = conn.decodeJid(contact.id)
			if (store && store.contacts) store.contacts[id] = {
				id,
				name: contact.notify
			}
		}
	})
}

start()