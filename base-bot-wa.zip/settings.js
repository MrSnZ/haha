module.exports = {
  nameBot: "MyBot",
  prefix: [".", "!", "/"],

  // Daftar Owner Default (pakai nomor tanpa @s.whatsapp.net)
  owner: [
    "6282241182487",  // Owner utama
    "6289876543210"   // Owner kedua (opsional)
  ],

  // Link & thumbnail (opsional)
  lynk: "https://github.com/username",
  thumb3: "https://telegra.ph/file/xxx.jpg",
};