const handler = async (m, { conn, args, db }) => {
  let who = m.mentionedJid && m.mentionedJid[0]
    ? m.mentionedJid[0]
    : args[0]?.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

  if (!who) return m.reply(`Contoh:\n!addprem @tag\n!addprem 6281234567890`)

  let user = db.list().user[who] ||= { exp: 0, limit: 10, money: 0, premium: false }
  if (user.premium) return m.reply('User ini sudah Premium.')

  user.premium = true
  await db.save()

  m.reply(`✅ ${who} sekarang jadi *User Premium*!`)
}

handler.command = ['addprem']
handler.category = 'owner'
handler.description = 'Menambahkan status Premium ke user'
handler.owner = true

module.exports = handler