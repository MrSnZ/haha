const handler = async (m, { conn, args, db }) => {
  let who = m.mentionedJid && m.mentionedJid[0]
    ? m.mentionedJid[0]
    : args[0]?.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

  if (!who) return m.reply(`Contoh:\n!delprem @tag\n!delprem 6281234567890`)

  let user = db.list().user[who]
  if (!user || !user.premium) return m.reply('User ini bukan Premium.')

  user.premium = false
  await db.save()

  m.reply(`✅ ${who} status Premium-nya sudah dicabut.`)
}

handler.command = ['delprem']
handler.category = 'owner'
handler.description = 'Menghapus status Premium dari user'
handler.owner = true

module.exports = handler