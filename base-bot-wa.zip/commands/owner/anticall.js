const handler = async (m, { args, db }) => {
  if (!db.list().settings) db.list().settings = { anticall: false }

  if (!args[0]) return m.reply(`Contoh:\n!anticall on\n!anticall off`)

  if (args[0].toLowerCase() === 'on') {
    db.list().settings.anticall = true
    await db.save()
    return m.reply('✅ Anti-Call diaktifkan. Bot akan menolak semua panggilan.')
  }

  if (args[0].toLowerCase() === 'off') {
    db.list().settings.anticall = false
    await db.save()
    return m.reply('❌ Anti-Call dimatikan.')
  }

  return m.reply('Pilihan hanya: on / off')
}

handler.command = ['anticall']
handler.category = 'owner'
handler.description = 'Mengaktifkan/menonaktifkan anti-call'
handler.owner = true

module.exports = handler