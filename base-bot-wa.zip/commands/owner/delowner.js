const handler = async (m, { conn, args, db }) => {
  let who = m.mentionedJid && m.mentionedJid[0]
    ? m.mentionedJid[0]
    : args[0]?.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

  if (!who) return m.reply(`Contoh:\n!delowner @tag\n!delowner 6281234567890`)

  let index = db.list().owner.indexOf(who)
  if (index === -1) return m.reply('User ini bukan Owner.')

  db.list().owner.splice(index, 1)
  await db.save()

  m.reply(`✅ ${who} sudah dihapus dari *Owner*.`)
}

handler.command = ['delowner']
handler.category = 'owner'
handler.description = 'Menghapus Owner'
handler.owner = true

module.exports = handler