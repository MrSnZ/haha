const handler = async (m, { conn }) => {
  m.reply('Pong!')
}

handler.command = ['ping']
handler.category = 'owner'
handler.description = 'Cek respon bot'
handler.owner = true

module.exports = handler