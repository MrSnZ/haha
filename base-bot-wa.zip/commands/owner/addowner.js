const handler = async (m, { conn, args, db }) => {
  let who = m.mentionedJid && m.mentionedJid[0]
    ? m.mentionedJid[0]
    : args[0]?.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

  if (!who) return m.reply(`Contoh:\n!addowner @tag\n!addowner 6281234567890`)

  if (db.list().owner.includes(who)) return m.reply('User ini sudah jadi Owner.')
  db.list().owner.push(who)
  await db.save()

  m.reply(`✅ Berhasil menambahkan ${who} sebagai *Owner*.`)
}

handler.command = ['addowner']
handler.category = 'owner'
handler.description = 'Menambahkan Owner baru'
handler.owner = true

module.exports = handler