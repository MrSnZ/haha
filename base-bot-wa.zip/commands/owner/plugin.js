const fs = require('fs')
const path = require('path')

const handler = async (m, { conn, args, command, text }) => {
  const baseDir = path.join(__dirname, '../..', 'commands') // folder commands/
  let subcmd = command.toLowerCase()

  if (subcmd === 'addplugin') {
    if (!args[0]) return m.reply('Contoh: !addplugin owner/delprem.js\n(lalu reply kode JS nya)')
    if (!m.quoted || !m.quoted.text) return m.reply('Reply dengan kode plugin!')
    
    let filePath = path.join(baseDir, args[0])
    let dir = path.dirname(filePath)

    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
    fs.writeFileSync(filePath, m.quoted.text)

    m.reply(`✅ Plugin berhasil ditambahkan di *${args[0]}*`)
    return
  }

  if (subcmd === 'delplugin') {
    if (!args[0]) return m.reply('Contoh: !delplugin owner/delprem.js')
    let filePath = path.join(baseDir, args[0])
    if (!fs.existsSync(filePath)) return m.reply('Plugin tidak ditemukan.')

    fs.unlinkSync(filePath)
    m.reply(`✅ Plugin *${args[0]}* berhasil dihapus.`)
    return
  }

  if (subcmd === 'daftarplugin') {
    let plugins = []

    const walk = (dir) => {
      fs.readdirSync(dir).forEach(file => {
        let filepath = path.join(dir, file)
        if (fs.lstatSync(filepath).isDirectory()) walk(filepath)
        else if (file.endsWith('.js')) {
          plugins.push(path.relative(baseDir, filepath))
        }
      })
    }
    walk(baseDir)

    if (plugins.length === 0) return m.reply('Belum ada plugin.')
    m.reply(`📂 *Daftar Plugin:*\n\n${plugins.map(p => '• ' + p).join('\n')}`)
    return
  }

  if (subcmd === 'isiplugin') {
    if (!args[0]) return m.reply('Contoh: !isiplugin owner/delprem.js')
    let filePath = path.join(baseDir, args[0])
    if (!fs.existsSync(filePath)) return m.reply('Plugin tidak ditemukan.')

    let isi = fs.readFileSync(filePath, 'utf-8')
    if (isi.length > 3000) return m.reply('Isi plugin terlalu panjang!')
    m.reply(`📄 Isi plugin *${args[0]}*:\n\n${isi}`)
    return
  }
}

handler.command = ['addplugin', 'delplugin', 'daftarplugin', 'isiplugin']
handler.category = 'owner'
handler.description = 'Manajemen plugin dinamis (tambah/hapus/list/lihat isi)'
handler.owner = true

module.exports = handler