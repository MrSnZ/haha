const handler = async (m, { text, db }) => {
  if (!m.isGroup) return m.reply('Fitur ini hanya untuk grup!')
  if (!text) return m.reply(`Contoh:\n!setwelcome Halo @user, selamat datang di grup @subject`)

  let group = db.list().group[m.chat] ||= {}
  group.textWelcome = text
  await db.save()

  m.reply('✅ Pesan welcome berhasil diubah!')
}

handler.command = ['setwelcome']
handler.category = 'group'
handler.description = 'Atur pesan welcome grup (@user dan @subject bisa dipakai)'
handler.group = true
handler.admin = true

module.exports = handler