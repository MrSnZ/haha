const handler = async (m, { args, db }) => {
  if (!m.isGroup) return m.reply('Fitur ini hanya untuk grup!')
  let group = db.list().group[m.chat] ||= { welcome: false }

  if (!args[0]) return m.reply(`Contoh:\n!welcome on\n!welcome off`)

  if (args[0].toLowerCase() === 'on') {
    group.welcome = true
    await db.save()
    return m.reply('✅ Welcome/Leave aktif di grup ini')
  } else if (args[0].toLowerCase() === 'off') {
    group.welcome = false
    await db.save()
    return m.reply('❌ Welcome/Leave dimatikan di grup ini')
  } else {
    return m.reply('Pilihan hanya: on / off')
  }
}

handler.command = ['welcome']
handler.category = 'group'
handler.description = 'Mengaktifkan/menonaktifkan pesan welcome & leave di grup'
handler.group = true
handler.admin = true
handler.botAdmin = false

module.exports = handler