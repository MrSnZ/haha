const handler = async (m, { text, db }) => {
  if (!m.isGroup) return m.reply('Fitur ini hanya untuk grup!')
  if (!text) return m.reply(`Contoh:\n!setleave Selamat tinggal @user`)

  let group = db.list().group[m.chat] ||= {}
  group.textLeave = text
  await db.save()

  m.reply('✅ Pesan leave berhasil diubah!')
}

handler.command = ['setleave']
handler.category = 'group'
handler.description = 'Atur pesan leave grup (@user dan @subject bisa dipakai)'
handler.group = true
handler.admin = true

module.exports = handler