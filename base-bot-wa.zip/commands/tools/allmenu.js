const handler = async (m, { conn, usedPrefix }) => {
  let teks = `*── 「 ALL MENU 」 ──*\n\n`
  
  // Kelompokkan command berdasarkan kategori
  let categories = {}
  for (let plugin of global.plugins) {
    let cat = plugin.category || 'lainnya'
    if (!categories[cat]) categories[cat] = []
    categories[cat].push(plugin)
  }

  // Looping kategori
  for (let [cat, cmds] of Object.entries(categories)) {
    teks += `\n*${cat.toUpperCase()}*\n`
    for (let cmd of cmds) {
      let commands = cmd.command.map(c => usedPrefix + c).join(', ')
      teks += `• ${commands} → ${cmd.description || '-'}\n`
    }
  }

  m.reply(teks.trim())
}

handler.command = ['allmenu', 'menu', 'help']
handler.category = 'tools'
handler.description = 'Menampilkan semua menu/command bot'
handler.owner = false
handler.limit = false

module.exports = handler