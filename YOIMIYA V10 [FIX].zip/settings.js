///SC RECODE BY DINZID VyL
// © RECODE BY DinzID Vyl 2022 - 2025
// CR BASE  : @DanzNano
//JANGAN HAPUS CREDITS!! HAPUS? = GW ENC SEMUA!! 
// BEBAS RECODE !
require('./sistem/decor');
const chalk = require("chalk")
const fs = require("fs")
//aumto presence update
global.autoTyping = false //auto tying in gc (true to on, false to off)
global.autoRecord = false //auto recording (true to on, false to off)
global.autoblockmorroco = true //auto block 212 (true to on, false to off)
global.autokickmorroco = true //auto kick 212 (true to on, false to off) 
global.antispam = false//auto kick  (true to on, false to off)
global.gruponly = false
global.pconly = false
global.reactsw = ["😁","😃","👍"] //kalau kurang tambahhin aja
//////////////////////////////////////////////////////////////////////////////////

// TAG OWN 
global.pvt = 'https://files.catbox.moe/q29ze7.mp4'
// UBAH BAGIAN THUMBNAIL MENU & ALLMENU \\
global.thumbnail = 'https://img3.teletype.in/files/20/47/2047944a-d1a1-4b06-9d73-20b98779a96f.jpeg', //THUMB MENU KALIAN
global.dinzmenu = 'https://files.catbox.moe/jsv33h.jpg', //THUMB MENU button KALIAN
// 


// AUTOPROMOSI 
global.promosi = false
global.jedapromosi = 3600000 // 1 jam
global.delaypromosi = 3000 // 5 detik
global.promoData = {
image: '', // url 
caption: '' 
}


// WELCOME SETTINGS \\
global.wlcmimg = 'https://img2.teletype.in/files/1b/5f/1b5f0a94-4daf-4354-8239-53006bab1b80.jpeg'
global.leftimg = 'https://img1.teletype.in/files/80/37/8037ce95-98c9-41fc-90d6-23d0cc166dec.jpeg'
global.wlcm = true //UNTUK AUTO WELCOMENYA
global.textwlcm = `
┌─┉─ • ─┉─  ── .✦
│𝘄𝗲𝗹𝗹𝗰𝝾𝗺𝗲 𝗻𝗲𝘄 𝗺𝗲𝗺, 𝗶𝗻𝘁𝗿𝝾 𝗱𝘂𝗹𝘂 𝘆𝘂𝗸! 
│𝗻𝝰𝗺𝝰 :
│𝝰𝘀𝗸𝝾𝘁 :
│𝘂𝗺𝘂𝗿 :
│𝗺𝝰𝗸𝝰𝘀𝗶𝗵 𝘂𝗱𝝰𝗵 𝗶𝗻𝘁𝗿𝝾 ૮₍꜆꜄ ˃ ³ ˂ ₎ა 
└─┉─¡! • !¡─┉─ ── .✦`


// ( SEND NOTIF SHOWROOM JKT48) 
global.gcnotifjkt48 = '120363335406266355@g.us'
global.notifchjkt48 = '120363418800241257@newsletter'
global.own = "6283840390064@s.whatsapp.net"


// FAKE REPLY/FAKE QUOTED 
global.replyyoimiya = 'https://files.catbox.moe/4wbhkk.jpg'
global.replyDinzID = 'https://img3.teletype.in/files/27/ab/27ab12a7-03cc-49f5-b7d9-6aa300064ed3.jpeg'
global.replydinz = 'https://files.catbox.moe/b7m6c0.jp'
global.reply = 'https://files.catbox.moe/4wbhkk.jpg'



// SETTING TAMPILAN MENU KALIAN \\
global.ig2 = '' //NAMA IG LU
global.ig = '' //NAMA IG LU
global.yt = 'Zerone Official' //NAMA YT LU, KALO GADA GAUSAH DIISI
global.ttowner = '' //NAMA TIKTOK LU
global.ownername = 'Zerone Official' //NAMA LU
global.owner = ['6283840390064'] // 𝚂𝙴𝚃𝚃𝙸𝙽𝙶 𝙳𝙸 𝙵𝙾𝙻𝙳𝙴𝚁 𝙿𝚁𝙴𝙼 
global.ownernomer = '6283840390064' // NOMOR LU
global.socialm = 'GitHub:ZeroneOffcial-'
global.location = 'Indonesia' 
global.nameCreator = 'Zerone Official'
//



// SETTING PAYMENT KALIAN 
global.nodana = '' // KOSONG KAN JIKA TIDAK ADA
global.nogopay = '' // KOSONG KAN JIKA TIDAK ADA 
global.noovo = '' // KOSONG KAN JIKA TIDAK ADA
//






// SETTING PAYMENT NAME 
global.andana = '' // KOSONG KAN JIKA TIDAK ADA
global.angopay = '' // KOSONG KAN JIKA TIDAK ADA
global.anovo = '' // KOSONG KAN JIKA TIDAK ADA
// 



// SETTING BOT 
global.botname = "ʏᴏɪᴍɪʏᴀ ᴀssɪsᴛᴇɴᴛ" //NAMA BOT LU
global.ownernumber = '6283840390064' //NOMOR LU
global.botnumber = '6283840390064' //NOMOR LU
global.ownername = 'Zerone Official' //NAMA LU
global.idsal = "120363418800241257@newsletter"
global.idSaluran = "120363418800241257@newsletter"//ID SALURAN LU
global.idch = "120363418800241257@newsletter"//ID SALURAN LU
global.chat = '120363418800241257@newsletter'
global.namaSaluran = "Yoimiya Assistent"
global.saluranName = "Yoimiya Assistent"
global.linkSaluran = "https://whatsapp.com/channel/0029VbB32Eb2UPBPGnOVAr1s"
global.ownerNumber = ["6283840390064@s.whatsapp.net"] //NOMORLU
global.ownerweb = "https://websitekita.verce.app"//WEB LU//OPSIONAL
global.websitex = "https://websitekita.vercel.app"//OPSIONAL
global.wagc = "https://chat.whatsapp.com/CEoqekcix8gDTrCJPZJGub?mode=ac_t"
global.wach = 'https://whatsapp.com/channel/0029VbB32Eb2UPBPGnOVAr1s'
global.saluran = "https://whatsapp.com/channel/0029VbB32Eb2UPBPGnOVAr1s"
global.themeemoji = '🪀'
global.wm = "Yoimiya Assistent"
global.botscript = 'https://websitekita.vercel.app'
global.packname = "Zerone | Yoimiya"
global.author = "\n\nCreate by Zerone | Yoimiya Assistent\n Dev : Zerone Official"
global.creator = "6283840390064@s.whatsapp.net"
// 



// CPANEL FITUR 
global.domain = 'https://dinzxzan.biz.id' // Isi Domain Lu jangan kasih tanda / di akhir link
global.apikey = 'ptla_J5nnSqbvI8e0fTlhA9wQwv8izekOSQS8q3MgVQXP53d' // Isi Apikey Plta Lu
global.capikey = 'ptlc_CP3OYrh3iGSW3sKugzfnvmNWqCVClp8NdCSNlb4vh6y' // Isi Apikey Pltc Lu
//




// Server create panel egg pm2 
global.apikey2 = '-' // Isi Apikey Plta Lu
global.capikey2 = '-' // Isi Apikey Pltc Lu
global.domain2 = '-' // Isi Domain Lu
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //jangan di ubah
global.eggsnya2 = '15' // id eggs yang dipakai
global.location2 = '1' // id location
// 
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // id eggs yang dipakai
global.location3 = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
// 

global.my = {
    yt: "https://www.youtube.com/ZeroOffc"
}


/////////////////////////////////////////////////////////////////////////////////
global.mess = {
wait: "*_ᴛᴜɴɢɢᴜ sᴇʙᴇɴᴛᴀʀ ʏᴀ ᴋᴀᴋ._*",
   success: "sᴜᴋsᴇs ᴋᴀᴋ",
   on: "sᴜᴅᴀʜ ᴀᴋᴛɪғ", 
   off: "sᴜᴅᴀʜ ᴏғғ",
   query: {
       text: "ᴛᴇᴋs ɴʏᴀ ᴍᴀɴᴀ ᴋᴀᴋ ?",
       link: "ʟɪɴᴋ ɴʏᴀ ᴍᴀɴᴀ ᴋᴀᴋ ?",
   },
   error: {
       fitur: "ᴍᴏʜᴏɴ ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ᴇʀᴏʀ sɪʟᴀʜᴋᴀɴ ᴄʜᴀᴛ ᴅᴇᴠᴇʟᴏᴘᴇʀ ʙᴏᴛ ᴀɢᴀʀ ʙɪsᴀ sᴇɢᴇʀᴀ ᴅɪᴘᴇʀʙᴀɪᴋɪ",
   },
   only: {
       group: " ʏᴀʜ ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ᴅᴀʟᴀᴍ ɢʀᴏᴜᴘ",
       private: "ʏᴀʜ ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ᴅᴀʟᴀᴍ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ",
       owner: "ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ sᴀᴍᴀ ᴏᴡɴᴇʀ ʙᴏᴛ",
       admin: "ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ sᴀᴍᴀ ᴏᴡɴᴇʀ ʙᴏᴛ",
       badmin: "ᴍᴀᴀғ ᴋᴀᴋ ᴋᴀʏᴀ ɴʏᴀ ᴋᴀᴋᴀᴋ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ғɪᴛᴜʀ ɪɴɪ ᴅɪ ᴋᴀʀᴇɴᴀᴋᴀɴ ʙᴏᴛ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ",
       premium: "ᴍᴀᴀғ ᴋᴀᴍᴜ ʙᴇʟᴏᴍ ᴍᴇɴᴊᴀᴅɪ ᴜsᴇʀ ᴘʀᴇᴍɪᴜᴍ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴘʀᴇᴍɪᴜᴍ sɪʟᴀᴋᴀɴ ʙᴇʟɪ ᴅɪ ᴏᴡɴᴇʀ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ ᴋᴇᴛɪᴋ  .ᴏᴡɴᴇʀ",
   }
}


global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//new
global.tempatDB = 'database.json' // Jangan ubah
global.prefix = ['.']
global.XznKey = "rafael"
global.sessionName = 'session' // Jangan di ubah takut nanti error
global.hituet = 0
//media target
global.thum = fs.readFileSync("./media/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./media/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./media/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./media/thumb.jpg") //ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

global.keyopenai = "pk-pIWAlRroXTOAigkWdHcYvmlmgzEQXuoMWbVAaLAVZswSRbEB"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
