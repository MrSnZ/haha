const config = require("@configuration");

module.exports = (myth) => {
  const lastCall = new Map();

  myth.ev.on("call", async (callData) => {
    if (!config.settings.antiCall) return;

    for (const call of callData) {
      const now = Date.now();
      const lastCallTime = lastCall.get(call.from) || 0;

      if (now - lastCallTime > 5000) {
        lastCall.set(call.from, now);
        
        await myth.rejectCall(call.id, call.from);
        await myth.sendMessage(call.from, {
          text: `🚫 ${config.messages.call}`,
          mentions: [call.from]
        });
      }
    }
  });
};