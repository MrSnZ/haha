const { generateWAMessage, areJidsSameUser, proto } = require("baileys");

async function events(m, { myth }) {
  myth.sendAliasMessage = async (jid, mess = {}, alias = {}, quoted = null) => {
    function check(arr) {
      if (!Array.isArray(arr)) {
        return false;
      }
      if (!arr.length) {
        return false;
      }
      for (let i = 0; i < arr.length; i++) {
        const item = arr[i];
        if (typeof item !== "object" || item === null) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(item, "alias")) {
          return false;
        }
        if (!Array.isArray(item.alias) && typeof item.alias !== "string") {
          return false;
        }
        if (
          Object.prototype.hasOwnProperty.call(item, "response") &&
          typeof item.response !== "string"
        ) {
          return false;
        }
        if (
          Object.prototype.hasOwnProperty.call(item, "eval") &&
          typeof item.eval !== "string"
        ) {
          return false;
        }
      }
      return true;
    }
    if (!check(alias)) return "Alias format is not valid!";
    let message = await myth.sendMessage(jid, mess, {
      quoted: quoted,
    });
    if (typeof myth.alias[jid] === "undefined") myth.alias[jid] = {};
    myth.alias[jid][message.key.id] = {
      chat: jid,
      id: message.key.id,
      alias,
    };
    return message;
  };
  myth.sendInputMessage = async (
    jid,
    mess = {},
    target = "all",
    timeout = 60000,
    quoted = null,
  ) => {
    let time = Date.now();
    let message = await myth.sendMessage(jid, mess, {
      quoted: quoted,
    });
    if (typeof myth.input[jid] === "undefined") myth.input[jid] = {};
    myth.input[jid][message.key.id] = {
      chat: jid,
      id: message.key.id,
      target,
    };

    while (
      Date.now() - time < timeout &&
      !myth.input[jid][message.key.id].hasOwnProperty("input")
    )
      await myth.delay(500);

    return myth.input[jid][message.key.id].input;
  };

  if (typeof myth.alias === "undefined") myth.alias = {};
  if (typeof myth.input === "undefined") myth.input = {};

  if (m.quoted) {
    const quotedId = m.quoted.id;
    if (
      myth.input[m.cht]?.[quotedId]?.target === "all" ||
      myth.input[m.cht]?.[quotedId]?.target === m.sender
    ) {
      myth.input[m.cht][quotedId].input = m.body;
    }
    if (myth.alias.hasOwnProperty(m.cht)) {
      if (myth.alias[m.cht].hasOwnProperty(quotedId)) {
        for (const aliasObj of myth.alias[m.cht][quotedId].alias) {
          if (
            Array.isArray(aliasObj.alias) &&
            !aliasObj.alias
              .map((v) => v.toLowerCase())
              .includes(m.body.toLowerCase())
          )
            continue;
          else if (aliasObj.alias.toLowerCase() !== m.body.toLowerCase())
            continue;
          else {
            if (aliasObj.response) await m.emit(aliasObj.response);
            if (aliasObj.eval) await eval(aliasObj.eval);
          }
        }
      }
    }
  }
}

module.exports = {
  events,
};
