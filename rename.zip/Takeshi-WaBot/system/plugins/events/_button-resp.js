async function events(m, { myth }) {
  if (m.type === "interactiveResponseMessage" && m.quoted.fromMe) {
    myth.appendTextMessage(
      m,
      JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id,
      m,
    );
  }
  if (m.type === "templateButtonReplyMessage" && m.quoted.fromMe) {
    myth.appendTextMessage(m, m.msg.selectedId, m);
  }
}

module.exports = {
  events,
};
