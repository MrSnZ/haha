module.exports = (max) => Math.floor(Math.random(), max);
